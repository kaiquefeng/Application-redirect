<?php 

    $senha = $_POST["password"];
    $email = $_POST["email"];

    if (($senha) == "1234" && ($email) == "lucas@380volts.com.br") {

        header('Location: https://app.powerbi.com/view?r=eyJrIjoiOTc0OTllNTktZGRkOC00YmY3LTgwNTQtOTA5ZTEzMmZiOWEwIiwidCI6ImFmMWRjZThkLTM3NmItNDE5ZS1hNTIwLTU3NmFiMTZjM2M5ZCJ9');
        
    } else (($senha) == "123" && ($email) == "contato@380volts.com.br"); { 
        
        header('Location: https://registro.br/cgi-bin/nicbr/dominio?dominio=380v.com.br');
    }
?>